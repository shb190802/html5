module.exports = {
  publicPath: './',
  outputDir: 'gdp'
}