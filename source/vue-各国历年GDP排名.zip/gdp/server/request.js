const axios = require('axios')
const colors = require('colors')

function requestHtml(url) {
  console.log('start fetch ',url)
  return new Promise((resolve,reject) => {
    axios.get(url).then(res => {
      console.log('fetch success'.green)
      resolve(res.data)
    }).catch(err=>{
      console.log('fetch error '.yellow)
      reject('')
    })
  })
}

module.exports = {
  requestHtml
}