const COLORS = ['#09b296', '#31c5e9', '#66e0e3', '#9fe6b7', '#ffdb5c', '#ff9f7f', '#fc7193', '#e062ae', '#e690d1', '#e7bcf3','#BF3EFF',"#EE7942","#FFD700","#FFD700","#FF00FF","#EE7621","#BCEE68"].sort(()=>Math.random() > 0.5 ? 1 : -1)

const CHINA_COLOR = '#E60000'

module.exports = {
  COLORS,CHINA_COLOR
}