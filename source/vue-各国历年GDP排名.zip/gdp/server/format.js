const data = require('./data.json')
const fs = require('fs')
const path = require('path')
const {
  CHINA_COLOR,
  COLORS
} = require('./config')

let newData = {}
let startYear = 1960
let endYear = 2018
let colors = {
  '中国': CHINA_COLOR
}

for(let i = startYear ; i <= endYear ; i ++) {
  let yearData = data[i].slice(0,10).map(country=> {
    let gbp = country[3].split('亿')[0]
    let sum = 0
    if(gbp.indexOf('万') !== -1) {
      sum = Number(gbp.split('万')[0])
      sum *= 10000
    }else {
      sum = Number(gbp)
    }
    if(!colors[country[1]]){
      colors[country[1]] = COLORS.shift()
    }
    return {
      no: country[0],
      name: country[1],
      gdp: gbp,
      sum: sum
    }
  })
  newData[i] = yearData
}

fs.writeFileSync(path.join(__dirname,'../src','data.js'),'export default ' + JSON.stringify(newData))
fs.writeFileSync(path.join(__dirname,'../src','colors.js'),'export default ' + JSON.stringify(colors))