const { requestHtml } = require('./request')
const cheerio = require('cheerio')
const fs = require('fs')
const path = require('path')

async function loadGDP(){
  let startYear = 1960
  let endYear = 2018
  let result = {}
  for(let year = startYear ; year <= endYear ;year ++) {
    let html = await requestHtml(`https://www.kuaiyilicai.com/stats/global/yearly/g_gdp/${year}.html`)
    if(html){
      let list = []
      const $ = cheerio.load(html)
      let dataList = Array.from($('tbody tr'))
      dataList.forEach(tr => {
        if(!tr.attribs.class){
          let rank = []
          Array.from(tr.children).forEach(td => {
            if(td.name === 'td' && td.children.length) {
              rank.push(td.children[0].data.trim())
            }
          })
          list.push(rank)
        }
      })
      result[''+year] = list
    }
  }
  fs.writeFileSync(path.join(__dirname,'data.json'),JSON.stringify(result))
}
loadGDP()