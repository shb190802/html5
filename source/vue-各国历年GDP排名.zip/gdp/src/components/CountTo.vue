<template>
  <div>
    {{cur | money}}
  </div>
</template>
<script>
const DELAY = 100

export default {
  name: 'CountTo',
  props: {
    dist: {
      type: Number,
      default: 0
    },
    duration: {
      type: Number,
      default: 1000
    }
  },
  data(){
    return {
      cur: this.dist - 100,
      timer: 0
    }
  },
  watch:{
    'dist':{
      handler(){
        this.$nextTick(() => {
          this.countTo()
        })
      }
    }
  },
  filters: {
    money(v){
      if(v > 10000) {
        v /= 10000
        return v.toFixed(2) + '万亿'
      }
      return v.toFixed(2) + '亿'
    }
  },
  methods: {
    countTo(){
      let cur = this.cur
      let dist = this.dist
      let step = (this.dist - this.cur) /(this.duration/DELAY)
      this.timer && clearInterval(this.timer)
      this.timer = setInterval(() => {
        this.cur = Math.min(this.cur + step,this.dist)
        if(this.cur === this.dist) {
          clearInterval(this.timer)
        }
      },DELAY)
    }
  }
}
</script>