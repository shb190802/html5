<template>
  <div id="app">
    <div class="box" :style="{width: width,height:height}">
      <div class="header">{{year}}年（美元）</div>
      <transition-group tag="ul" name='transition'>
        <li v-for="(item,index) in list" :key="item.name" class="item" >
          <div class="item" :style="{transform:top(index)}">
            <div class="country">{{item.name}}</div>
            <div class="process">
              <div class="outer" :style="{width: process}">
                <div class="inner" :style="{width: countryProcess(item.sum),background: colors[item.name]}">
                  <div class="gdp">
                    <CountTo :dist="item.sum" :duration="1000" />
                  </div>
                </div>
              </div>
            </div>
            <div style="width:80px;"></div>
          </div>
        </li>
      </transition-group>
    </div>
  </div>
</template>

<script>
import GDBList from './data'
import COLORS from './colors'
import CountTo from './components/CountTo'
let timer = 0
let startYear = 1960
let endYear = 2018
export default {
  name: 'app',
  components: {
    CountTo
  },
  data(){
    return {
      year: startYear,
      itemHeight: 30,
      colors: COLORS,
      width: window.innerHeight + 'px',
      height: window.innerWidth + 'px',
      init:[]
    }
  },
  computed:{
    list(){
      return this.init || GDBList[this.year]
    },
    process(){
      return 90 - (endYear - this.year )/(endYear - startYear) * 40 + '%'
    }
  },
  created(){
    let init = []
    let isFirst = true
    for(let key in COLORS) {
      init.push({
        name: key,
        sum: isFirst ? 1 : 0
      })
      isFirst = false
    }
    this.init = init
  },
  mounted(){
    this.init = null
    timer = setInterval(() => {
      this.year += 1
      if(this.year >= 2018) {
        clearInterval(timer)
      }
    },600)
  },
  methods:{
    countryProcess(sum){
      return sum / this.list[0].sum * 100 + '%'
    },
    top(index){
      return `translateY(${index*this.itemHeight + 'px'})`
    }
  }
}
</script>

<style>
html,body{
  height: 100%;
  background: #F0F0F0;
}
html,body,div,ul,li{
  margin: 0;
  padding: 0;
}
ul,li{
  list-style: none;
}
.box{
  position: absolute;
  left: 100%;
  transform-origin: left top;
  transform: rotate(90deg);
  overflow: hidden;
}
ul{
  position: relative;
}
.header{
  height: 40px;
  line-height: 40px;
  text-align: center;
}
.item {
  position: absolute;
  left: 0;
  width: 100%;
  display: flex;
  height: 30px;
  line-height: 30px;
  font-size: 12px;
  transition: transform 500ms;
}
.country{
  width: 60px;
  text-align: center;
}
.process {
  flex: 1;
}
.outer{
  transition: width 600ms linear;
}
.inner{
  position: relative;
  margin-top: 5px;
  height: 20px;
  transition: width 600ms linear;
}
.gdp{
  position: absolute;
  left: 100%;
  margin-left: 20px;
  line-height: 20px;
  width: 80px;
}
.transition-move{
  transition: transform 500ms;
}
.transition-enter,.transition-leave-to{
  transform: translateY(100%);
  opacity: 0;
}
.transition-enter-active, .transition-leave-active {
  transition: 500ms;
}
.transition-enter-to,.transition-leave{
  transform: translateY(0);
  opacity: 1;
}
</style>
