module.exports = {
  publicPath: './',
  outputDir: 'dandelion'
}