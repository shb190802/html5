<template>
  <div class="main">
    <div
      v-for="(item,index) in branches"
      :key="index"
      :style="{transform: item.rotateY}"
      class="branch"></div>
    <div class="footer"></div>
  </div>
</template>
<script>
export default {
  name: 'Petal',
  data(){
    return {
      branches:[],
      limit: 9
    }
  },
  created(){
    for(var i = 0 ; i < this.limit ; i ++) {
      this.branches.push({
        rotateY: `rotateY(${~~(180/this.limit*i)}deg)`
      })
    }
  }
}
</script>
<style>
.main{
  position: absolute;
  left: 0;
  bottom: 0;
  width: 0;
  height: 50px;
  transform-style: preserve-3d;
}
.main::before{
  position: absolute;
  content: '';
  left: -1px;
  bottom: 0;
  width: 2px;
  height: 100%;
  background: rgba(255,255,255,.3);
}
.main::after{
  position: absolute;
  content: '';
  left: -1px;
  top: 0;
  width: 2px;
  height: 100%;
  background: rgba(255,255,255,.3);
  transform: rotateY(90deg);
}
.footer {
  position: absolute;
  left: -2px;
  width: 4px;
  height: 16px;
  bottom: 0;
}
.footer::before{
  position: absolute;
  content: '';
  left: 0;
  bottom: 0;
  width: 100%;
  height: 100%;
  border-radius: 50% 50% 30% 30%;
  transform: rotateY(90deg);
  background: rgba(255,255,255,.4);
}
.footer::after{
  position: absolute;
  content: '';
  left: 0;
  bottom: 0;
  width: 100%;
  height: 100%;
  border-radius: 50% 50% 30% 30%;
  background: rgba(255,255,255,.4);
}
.branch{
  position: absolute;
  left: 0;
  top: -30px;
  height: 30px;
  transform-style: preserve-3d;
  transform-origin: bottom center;
}
.branch::before{
  position: absolute;
  content: '';
  left: 50%;
  bottom: 0;
  width: 40px;
  height: 24px;
  border-radius: 50%;
  transform-origin: bottom center;
  border-bottom: solid 3px rgba(255,255,255,.3);
  transform: translateX(-50%);
}
.branch::after{
  position: absolute;
  content: '';
  left: 50%;
  bottom: 0;
  width: 60px;
  height: 16px;
  border-radius: 50%;
  transform-origin: bottom center;
  border-bottom: solid 2px rgba(255,255,255,.3);
  transform: translateX(-50%);
}
</style>