<template>
  <div class="animate" :style="styles">
    <div class="horizontal" :style="stylesHorizontal">
      <div class="vertical" :style="stylesVertical">
        <Petal />
      </div>
    </div>
  </div>
</template>
<script>
import Petal from './Petal'
export default {
  name: 'Flower',
  components: {
    Petal
  },
  computed:{
    styles(){
      return `left:${this.left}px;bottom:${this.bottom}px;animation-delay:${this.delay}s;animation-duration:${this.duration}s`
    },
    stylesHorizontal(){
      return `animation-duration:${this.duration}s`
    },
    stylesVertical(){
      return `animation-duration:${this.duration}s`
    }
  },
  props:{
    left:{
      type: String | Number,
      default: 0
    },
    bottom:{
      type: String | Number,
      default: 0
    },
    delay:{
      type: Number,
      default: 0
    },
    duration:{
      type: Number,
      default: 6
    }
  }
}
</script>
<style>
.animate {
  position: absolute;
  width: 0;
  height: 0;
  transform-style: preserve-3d;
  animation: 6s rotate linear infinite;
}
@keyframes rotate {
  0%{transform: rotateY(0deg) rotateX(20deg)}
  100%{transform: rotateY(360deg) rotateX(20deg)}
}
.horizontal{
  position: absolute;
  width: 0;
  height: 0;
  animation: horizontal 4s ease-in-out infinite;
  transform-style: preserve-3d;
}
@keyframes horizontal {
  0%{transform: translate3d(0,0,0)}
  50%{transform: translate3d(100px,0,0)}
  100%{transform: translate3d(0,0,0)}
}
.vertical{
  position: absolute;
  width: 0;
  height: 0;
  animation: vertical 5s ease-in-out infinite;
  transform-style: preserve-3d;
}
@keyframes vertical {
  0%{transform: translate3d(0,0,0)}
  50%{transform: translate3d(0,-400px,0)}
  100%{transform: translate3d(0,0,0)}
}
</style>