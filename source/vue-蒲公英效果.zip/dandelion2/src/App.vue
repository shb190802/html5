<template>
  <div id="app">
    <Flower
      v-for="item in list"
      :key="item.delay"
      :bottom="item.bottom"
      :left="item.left"
      :delay="item.delay"
      :duration="item.duration"
      />
  </div>
</template>

<script>
import Flower from './components/Flower'
export default {
  name: 'app',
  components: {
    Flower
  },
  data(){
    return {
      list:[]
    }
  },
  created(){
    var limit = 4
    var width = ~~(window.innerWidth/2)
    for(var i = 0 ; i < limit ;i ++){
      this.list.push({
        left: width ,
        bottom: 60,
        delay: -1 * i,
        duration: 5 + Math.random()*3
      })
    }
  }
}
</script>

<style>
html,body{
  width: 100%;
  height: 100%;
}
html,body,div{
  margin: 0;
  padding: 0;
}
#app {
  position: absolute;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background: #000;
  display: flex;
  justify-content: center;
  align-items: center;
  perspective-origin: 50% 50%;
  perspective: 400px;
}
.container{
  position: absolute;
  bottom: 30px;
}
</style>
