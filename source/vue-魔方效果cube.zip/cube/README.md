# cube
vue 魔方特效

项目中使用vue-touch做触屏组件，建议在移动端环境下查看效果

See [演示地址](http://suohb.com/demo/win/cube/).

魔方效果
![Image text](http://suohb.com/demo/win/cube.png)