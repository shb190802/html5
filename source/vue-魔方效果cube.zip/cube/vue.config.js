module.exports = {
  outputDir: './cube',
  publicPath: process.env.NODE_ENV === 'development' ? '/' : './'
}